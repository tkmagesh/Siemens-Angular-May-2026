
import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  standalone: true,
  imports: [RouterLink],
  template: `
    <h2>Users</h2>
    <a [routerLink]="['/users', 1]">User 1</a>
  `
})
export class UsersComponent {}
